library(testthat)
library(wiggleplotr)

test_check("wiggleplotr")
